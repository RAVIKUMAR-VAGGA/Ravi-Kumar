import React, { useState } from 'react';
import { AuthContainer } from './AuthContainer';
import { InterviewApp } from './InterviewApp';

export default function AppLayout() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleAuthSuccess = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  if (!isAuthenticated) {
    return <AuthContainer onAuthSuccess={handleAuthSuccess} />;
  }

  return <InterviewApp onLogout={handleLogout} />;
}