import React, { useState } from 'react';
import { SignIn } from './auth/SignIn';
import { SignUp } from './auth/SignUp';
import { OTPVerification } from './auth/OTPVerification';

interface AuthContainerProps {
  onAuthSuccess: () => void;
}

type AuthStep = 'signin' | 'signup' | 'otp';

export const AuthContainer: React.FC<AuthContainerProps> = ({ onAuthSuccess }) => {
  const [currentStep, setCurrentStep] = useState<AuthStep>('signin');
  const [userPhone, setUserPhone] = useState('');

  const handleSignIn = (username: string, password: string) => {
    // In a real app, you'd validate credentials
    console.log('Sign in:', { username, password });
    onAuthSuccess();
  };

  const handleSignUp = (username: string, password: string, phone: string) => {
    console.log('Sign up:', { username, password, phone });
    setUserPhone(phone);
    setCurrentStep('otp');
  };

  const handleOTPVerification = (otp: string) => {
    // Demo OTP is 123456
    if (otp === '123456') {
      setCurrentStep('signin');
    } else {
      alert('Invalid OTP. Please use 123456 for demo.');
    }
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'signin':
        return (
          <SignIn
            onSignIn={handleSignIn}
            onSwitchToSignUp={() => setCurrentStep('signup')}
          />
        );
      case 'signup':
        return (
          <SignUp
            onSignUp={handleSignUp}
            onSwitchToSignIn={() => setCurrentStep('signin')}
          />
        );
      case 'otp':
        return (
          <OTPVerification
            onVerifyOTP={handleOTPVerification}
            phone={userPhone}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      {renderCurrentStep()}
    </div>
  );
};