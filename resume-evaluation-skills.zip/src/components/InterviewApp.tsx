import React, { useState } from 'react';
import { ResumeUpload } from './interview/ResumeUpload';
import { InterviewModeSelector } from './interview/InterviewModeSelector';
import { QuestionPanel } from './interview/QuestionPanel';
import { EvaluationPanel } from './interview/EvaluationPanel';
import { Button } from '@/components/ui/button';
import { LogOut } from 'lucide-react';

interface InterviewAppProps {
  onLogout: () => void;
}

type InterviewMode = 'tech' | 'communication' | 'techno-manager';

const SAMPLE_QUESTIONS = {
  tech: [
    'What is the difference between let, const, and var in JavaScript?',
    'Explain the concept of closures in JavaScript.',
    'What are React hooks and why are they useful?'
  ],
  communication: [
    'Tell me about a time when you had to explain a complex technical concept to a non-technical person.',
    'How do you handle conflicts in a team environment?',
    'Describe your approach to giving constructive feedback.'
  ],
  'techno-manager': [
    'How would you prioritize features in a product roadmap?',
    'Describe your experience leading a technical team.',
    'How do you balance technical debt with new feature development?'
  ]
};

const SAMPLE_ANSWERS = {
  tech: [
    'var is function-scoped and can be redeclared, let is block-scoped and cannot be redeclared, const is block-scoped and cannot be reassigned.',
    'Closures allow inner functions to access variables from outer functions even after the outer function has returned.',
    'React hooks allow functional components to use state and lifecycle methods, making code more reusable and easier to test.'
  ],
  communication: [
    'I use analogies and visual aids to break down complex concepts into relatable terms, ensuring understanding through questions.',
    'I listen to all perspectives, find common ground, and focus on solutions that benefit the team and project goals.',
    'I provide specific examples, focus on behaviors rather than personality, and offer actionable suggestions for improvement.'
  ],
  'techno-manager': [
    'I use frameworks like RICE scoring, consider business impact, user needs, and technical feasibility when prioritizing features.',
    'I focus on clear communication, setting expectations, providing mentorship, and removing blockers for my team.',
    'I allocate 20% of sprint capacity to technical debt, ensuring long-term maintainability while delivering new features.'
  ]
};

export const InterviewApp: React.FC<InterviewAppProps> = ({ onLogout }) => {
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [selectedMode, setSelectedMode] = useState<InterviewMode | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [showEvaluation, setShowEvaluation] = useState(false);
  const [score, setScore] = useState(0);

  const handleResumeUpload = (file: File) => {
    setResumeFile(file);
  };

  const handleModeSelect = (mode: InterviewMode) => {
    setSelectedMode(mode);
    setCurrentQuestionIndex(0);
    setUserAnswer('');
    setShowEvaluation(false);
  };

  const handleAnswerSubmit = (answer: string) => {
    setUserAnswer(answer);
  };

  const handleEvaluate = () => {
    const randomScore = Math.floor(Math.random() * 4) + 7; // 7-10
    setScore(randomScore);
    setShowEvaluation(true);
  };

  const handleNext = () => {
    if (selectedMode && currentQuestionIndex < SAMPLE_QUESTIONS[selectedMode].length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setUserAnswer('');
      setShowEvaluation(false);
    } else {
      alert('Interview completed!');
    }
  };

  const getCurrentQuestion = () => {
    if (!selectedMode) return '';
    return SAMPLE_QUESTIONS[selectedMode][currentQuestionIndex];
  };

  const getCurrentSampleAnswer = () => {
    if (!selectedMode) return '';
    return SAMPLE_ANSWERS[selectedMode][currentQuestionIndex];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">KODC0MM Interview Platform</h1>
          <Button onClick={onLogout} variant="outline">
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>

        {!resumeFile && (
          <ResumeUpload onResumeUpload={handleResumeUpload} />
        )}

        {resumeFile && !selectedMode && (
          <InterviewModeSelector
            onModeSelect={handleModeSelect}
            resumeUploaded={!!resumeFile}
          />
        )}

        {selectedMode && (
          <div className="space-y-6">
            <QuestionPanel
              question={getCurrentQuestion()}
              onAnswerSubmit={handleAnswerSubmit}
              isAnswering={!!userAnswer}
            />

            <EvaluationPanel
              userAnswer={userAnswer}
              sampleAnswer={getCurrentSampleAnswer()}
              score={score}
              onEvaluate={handleEvaluate}
              onPlaySampleAnswer={() => {}}
              onNext={handleNext}
              showEvaluation={showEvaluation}
            />
          </div>
        )}
      </div>
    </div>
  );
};