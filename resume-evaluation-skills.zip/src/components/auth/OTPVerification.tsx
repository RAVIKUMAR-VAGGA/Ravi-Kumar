import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';

interface OTPVerificationProps {
  onVerifyOTP: (otp: string) => void;
  phone: string;
}

export const OTPVerification: React.FC<OTPVerificationProps> = ({ onVerifyOTP, phone }) => {
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (otp.length !== 6) {
      setError('Please enter a 6-digit OTP');
      return;
    }
    
    onVerifyOTP(otp);
  };

  const handleOtpChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 6);
    setOtp(value);
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">Verify OTP</CardTitle>
        <p className="text-center text-gray-600">
          Enter the 6-digit code sent to {phone}
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="text-red-500 text-sm text-center">{error}</div>
          )}
          <div>
            <Label htmlFor="otp">6-Digit OTP</Label>
            <Input
              id="otp"
              type="text"
              value={otp}
              onChange={handleOtpChange}
              placeholder="Enter 6-digit OTP"
              className="text-center text-2xl tracking-widest"
              maxLength={6}
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={otp.length !== 6}>
            Verify OTP
          </Button>
          <div className="text-center text-sm text-gray-600">
            Demo OTP: 123456
          </div>
        </form>
      </CardContent>
    </Card>
  );
};