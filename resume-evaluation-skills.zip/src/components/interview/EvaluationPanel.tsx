import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Volume2, Star } from 'lucide-react';

interface EvaluationPanelProps {
  userAnswer: string;
  sampleAnswer: string;
  score: number;
  onEvaluate: () => void;
  onPlaySampleAnswer: () => void;
  onNext: () => void;
  showEvaluation: boolean;
}

export const EvaluationPanel: React.FC<EvaluationPanelProps> = ({
  userAnswer,
  sampleAnswer,
  score,
  onEvaluate,
  onPlaySampleAnswer,
  onNext,
  showEvaluation
}) => {
  const getScoreColor = (score: number) => {
    if (score >= 8) return 'bg-green-500';
    if (score >= 6) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const handlePlaySampleAnswer = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(sampleAnswer);
      speechSynthesis.speak(utterance);
    }
    onPlaySampleAnswer();
  };

  if (!userAnswer) return null;

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-xl font-bold">Answer Evaluation</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            onClick={onEvaluate}
            className="bg-blue-500 hover:bg-blue-600 text-white"
          >
            Evaluate
          </Button>
          
          <Button
            onClick={handlePlaySampleAnswer}
            variant="outline"
            className="flex items-center space-x-2"
          >
            <Volume2 className="h-4 w-4" />
            <span>Sample Answer</span>
          </Button>
          
          <Button
            onClick={onNext}
            className="bg-green-500 hover:bg-green-600 text-white"
          >
            NEXT
          </Button>
        </div>

        {showEvaluation && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <span className="font-semibold">Score:</span>
              <Badge className={`${getScoreColor(score)} text-white`}>
                {score}/10
              </Badge>
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(score / 2) ? 'text-yellow-400 fill-current' : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold mb-2 text-green-800">Sample Answer:</h4>
              <p className="text-green-700">{sampleAnswer}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};