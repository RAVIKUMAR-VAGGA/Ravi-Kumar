import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Code, MessageCircle, Users } from 'lucide-react';

interface InterviewModeSelectorProps {
  onModeSelect: (mode: 'tech' | 'communication' | 'techno-manager') => void;
  resumeUploaded: boolean;
}

export const InterviewModeSelector: React.FC<InterviewModeSelectorProps> = ({
  onModeSelect,
  resumeUploaded
}) => {
  const modes = [
    {
      id: 'tech' as const,
      title: 'Tech',
      icon: Code,
      description: 'Technical Interview',
      color: 'bg-blue-500 hover:bg-blue-600'
    },
    {
      id: 'communication' as const,
      title: 'Communication',
      icon: MessageCircle,
      description: 'Communication Skills',
      color: 'bg-green-500 hover:bg-green-600'
    },
    {
      id: 'techno-manager' as const,
      title: 'Techno Manager',
      icon: Users,
      description: 'Technical Management',
      color: 'bg-purple-500 hover:bg-purple-600'
    }
  ];

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">
          Select Interview Mode
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {modes.map((mode) => {
            const Icon = mode.icon;
            return (
              <Button
                key={mode.id}
                onClick={() => onModeSelect(mode.id)}
                disabled={!resumeUploaded}
                className={`h-32 flex flex-col items-center justify-center space-y-2 text-white ${
                  resumeUploaded ? mode.color : 'bg-gray-400'
                } transition-all duration-200 transform hover:scale-105`}
              >
                <Icon className="h-8 w-8" />
                <div className="text-center">
                  <div className="font-bold text-lg">{mode.title}</div>
                  <div className="text-sm opacity-90">{mode.description}</div>
                </div>
              </Button>
            );
          })}
        </div>
        {!resumeUploaded && (
          <p className="text-center text-gray-500 mt-4">
            Please upload your resume first to enable interview modes
          </p>
        )}
      </CardContent>
    </Card>
  );
};