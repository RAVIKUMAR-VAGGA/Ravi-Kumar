import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Volume2, VolumeX, Mic, MicOff } from 'lucide-react';

interface QuestionPanelProps {
  question: string;
  onAnswerSubmit: (answer: string) => void;
  isAnswering: boolean;
}

export const QuestionPanel: React.FC<QuestionPanelProps> = ({
  question,
  onAnswerSubmit,
  isAnswering
}) => {
  const [answer, setAnswer] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechInstance, setSpeechInstance] = useState<SpeechSynthesisUtterance | null>(null);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          setAnswer(prev => prev + ' ' + finalTranscript);
        }
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
        setIsRecording(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
        setIsRecording(false);
      };
    }
  }, []);

  const handleSpeakQuestion = () => {
    if ('speechSynthesis' in window) {
      if (isSpeaking) {
        speechSynthesis.cancel();
        setIsSpeaking(false);
        setSpeechInstance(null);
      } else {
        const utterance = new SpeechSynthesisUtterance(question);
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => {
          setIsSpeaking(false);
          setSpeechInstance(null);
        };
        utterance.onerror = () => {
          setIsSpeaking(false);
          setSpeechInstance(null);
        };
        setSpeechInstance(utterance);
        speechSynthesis.speak(utterance);
      }
    }
  };

  const speakAnswer = (text: string) => {
    if ('speechSynthesis' in window && text.trim()) {
      const utterance = new SpeechSynthesisUtterance(text);
      speechSynthesis.speak(utterance);
    }
  };

  const handleSubmit = () => {
    if (answer.trim()) {
      speakAnswer(answer);
      onAnswerSubmit(answer);
      setAnswer('');
    }
  };

  const toggleRecording = () => {
    if (!recognitionRef.current) return;

    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsRecording(true);
      setIsListening(true);
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-xl font-bold">Interview Question</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="flex items-start justify-between">
            <p className="text-lg flex-1">{question}</p>
            <Button
              onClick={handleSpeakQuestion}
              variant={isSpeaking ? "destructive" : "outline"}
              size="sm"
              className="ml-2"
            >
              {isSpeaking ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Textarea
              placeholder="Type your answer here or use voice recording..."
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              className="flex-1 min-h-[120px]"
            />
            <Button
              onClick={toggleRecording}
              variant={isRecording ? "destructive" : "outline"}
              size="sm"
              disabled={!recognitionRef.current}
            >
              {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </Button>
          </div>

          {isListening && (
            <div className="text-sm text-blue-600 flex items-center space-x-2">
              <div className="animate-pulse w-2 h-2 bg-red-500 rounded-full"></div>
              <span>Listening...</span>
            </div>
          )}

          <Button
            onClick={handleSubmit}
            disabled={!answer.trim()}
            className="w-full"
          >
            {isAnswering ? 'Submit Answer' : 'Give Answer'}
          </Button>
        </div>

        {answer && (
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Your Answer:</h4>
            <p className="text-gray-700">{answer}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};