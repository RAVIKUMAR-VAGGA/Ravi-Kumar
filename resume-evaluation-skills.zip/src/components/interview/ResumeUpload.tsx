import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, FileText } from 'lucide-react';

interface ResumeUploadProps {
  onResumeUpload: (file: File) => void;
}

export const ResumeUpload: React.FC<ResumeUploadProps> = ({ onResumeUpload }) => {
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState('');

  const handleFileSelect = (file: File) => {
    setError('');
    
    if (file.type !== 'application/pdf') {
      setError('Only PDF files are accepted');
      return;
    }
    
    onResumeUpload(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-3xl font-bold text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Welcome to KODC0MM APP
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            dragOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
          }`}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
        >
          <FileText className="mx-auto h-16 w-16 text-gray-400 mb-4" />
          <h3 className="text-lg font-semibold mb-2">Upload Your Resume</h3>
          <p className="text-gray-600 mb-4">Only PDF format is accepted</p>
          
          {error && (
            <div className="text-red-500 text-sm mb-4">{error}</div>
          )}
          
          <label htmlFor="resume-upload">
            <Button className="cursor-pointer" asChild>
              <span>
                <Upload className="mr-2 h-4 w-4" />
                UPLOAD RESUME
              </span>
            </Button>
          </label>
          
          <input
            id="resume-upload"
            type="file"
            accept=".pdf"
            onChange={handleFileInput}
            className="hidden"
          />
          
          <p className="text-sm text-gray-500 mt-4">
            Drag and drop your PDF file here or click to browse
          </p>
        </div>
      </CardContent>
    </Card>
  );
};